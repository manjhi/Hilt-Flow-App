package com.app.latestdemo.common

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.annotation.LayoutRes
import androidx.appcompat.widget.AppCompatTextView
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.app.latestdemo.R
import com.app.latestdemo.manager.appManager.AppDataManager
import com.app.latestdemo.services.ResultResource
import com.app.latestdemo.services.Status
import com.app.latestdemo.utils.LoadingDialog
import com.app.latestdemo.utils.showDialogFix
import com.app.latestdemo.utils.toStart
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Created by Manjinder Singh on 27,January,2022
 */
abstract class BaseFragment<T:ViewDataBinding> : Fragment() {

    @get:LayoutRes
    protected abstract val layoutResourceId: Int

    @Inject
    lateinit var loadingDialog: LoadingDialog

    @Inject
    lateinit var appDataManager: AppDataManager


    private var mViewDataBinding: T? = null
    private var mRootView: View? = null


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        mViewDataBinding = DataBindingUtil.inflate(inflater, layoutResourceId, container, false)
        mRootView = mViewDataBinding?.root
        initView()
        return mRootView
    }


    override fun onDestroyView() {
        super.onDestroyView()
        mRootView = null
        mViewDataBinding?.lifecycleOwner = null
        mViewDataBinding = null
        System.gc()
    }

    fun hideKeyboard() {
        val view: View? = requireActivity().currentFocus
        if (view != null) {
            val imm =
                requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager?
            imm?.hideSoftInputFromWindow(
                view.windowToken,
                InputMethodManager.RESULT_UNCHANGED_SHOWN
            )
        }
    }

    fun <T> checkStatus(
        showLoading: Boolean = true,
        result: ResultResource<T>,
        msg: String?
    ): Boolean {

        if (showLoading) {
            if (result is ResultResource.Loading)
                loadingDialog.setLoading(true)
            else
                loadingDialog.setLoading(false)
        }



        return when (result.status) {
            Status.SUCCESS -> {
                true
            }

            Status.ERROR -> {
                showError(msg ?:"Something went wrong")
                false
            }

            Status.NETWORK_ISSUE -> {
                showNetworkError()
                false
            }

            Status.UNAUTHORIZED -> {
                lifecycleScope.launch {
                    appDataManager.logOut()
                    requireActivity().toStart()
                    Toast.makeText(
                        requireContext(),
                        getString(R.string.token_expire),
                        Toast.LENGTH_SHORT
                    ).show()
                }
                false
            }
            else -> {
                false
            }
        }
    }

    fun showDialog(header: String?, message: String) {
        val dialog = requireContext().showDialogFix(R.layout.dialog_alert)
        val mHeader = dialog.findViewById<AppCompatTextView>(R.id.tvHeader)
        val mMessage = dialog.findViewById<AppCompatTextView>(R.id.tvMessage)
        val mOkay = dialog.findViewById<AppCompatTextView>(R.id.tvEnd)

        header?.let {
            mHeader.text = header

        }
        mMessage.text = message
        mOkay.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initData()
        mViewDataBinding!!.lifecycleOwner = this
        mViewDataBinding!!.executePendingBindings()
    }

    open fun getViewDataBinding(): T {
        return mViewDataBinding!!
    }


    abstract fun showError(message: String)
    abstract fun showNetworkError()
    abstract fun initView()
    abstract fun initData()
}