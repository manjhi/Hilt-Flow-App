package com.app.latestdemo.manager.dataStore

import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey

/**
 * Created by Manjinder Singh on 31,January,2022
 */
object DataStoreConstants {

    const val DataStoreName = "prefs"

    val USER_LOGGED_IN = booleanPreferencesKey("user_logged_in")
    val USER_DATA = stringPreferencesKey("user_data")
    val ACCESS_TOKEN = stringPreferencesKey("access_token")
    val USER_ID = intPreferencesKey("user_id")
}