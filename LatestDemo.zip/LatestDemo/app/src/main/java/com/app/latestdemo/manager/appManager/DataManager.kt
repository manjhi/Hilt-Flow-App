package com.app.latestdemo.manager.appManager

import com.app.latestdemo.domain.requestDto.LoginRequest
import com.app.latestdemo.manager.dataStore.DataStoreHelper
import com.app.latestdemo.services.ResultResource
import com.google.gson.JsonObject
import kotlinx.coroutines.flow.Flow

/**
 * Created by Manjinder Singh on 31,January,2022
 */
interface DataManager: DataStoreHelper {

    suspend fun login(jsonObject: LoginRequest):Flow<ResultResource<Any>>
}