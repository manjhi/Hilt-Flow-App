package com.app.latestdemo.modules.authModel

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.app.latestdemo.R
import com.app.latestdemo.common.BaseFragment
import com.app.latestdemo.databinding.FragmentLoginBinding
import com.app.latestdemo.domain.requestDto.LoginRequest
import com.app.latestdemo.utils.showSnackBar
import com.google.gson.Gson
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.runBlocking
import timber.log.Timber
@ExperimentalCoroutinesApi
@AndroidEntryPoint
class LoginFragment : BaseFragment<FragmentLoginBinding>() {

    private lateinit var binding: FragmentLoginBinding

    private val viewModel: LoginViewModel by viewModels()

    override val layoutResourceId: Int
        get() = R.layout.fragment_login

    override fun showError(message: String) {
        Timber.e(message)
        binding.clickButton.showSnackBar(message)
    }

    override fun showNetworkError() {

    }


    override fun initView() {
        binding = getViewDataBinding()

        binding.clickButton.setOnClickListener {
            var request = LoginRequest(
                Email = "danish@mailinator.com",
                Password = "123456781",
                DeviceToken = "FCM@SampleToken"
            )
            viewModel.loginUser(request)
        }
        observeLoginRequest()
    }

    private fun observeLoginRequest() {
        viewModel.loginResult.observe(viewLifecycleOwner) { result ->
            result.getContentIfNotHandled()?.let { response ->
                if (checkStatus(true, result.peekContent(), result.peekContent().msg)) {
                    runBlocking {
                        Timber.e(Gson().toJson(response.data))
                    }
                }
            }
        }
    }

    override fun initData() {

    }
}