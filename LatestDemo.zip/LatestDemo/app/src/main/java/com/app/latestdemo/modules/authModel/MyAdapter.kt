package com.app.latestdemo.modules.authModel

import com.app.latestdemo.R
import com.app.latestdemo.common.DataBindingAdapter
import com.app.latestdemo.common.DataBindingViewHolder
import com.app.latestdemo.common.DiffCallback
import com.app.latestdemo.common.GenericAdapter
import com.app.latestdemo.databinding.ItemListingBinding
import javax.inject.Inject

/**
 * Created by Manjinder Singh on 09,February,2022
 */
/*
class MyAdapter
@Inject
constructor() : DataBindingAdapter<String>(DiffCallback(), layoutView = R.layout.item_listing) {

    override fun onBindViewHolder(holder: DataBindingViewHolder<String>, position: Int) {
        super.onBindViewHolder(holder, position)
//       val bindingAdapter=(holder.itemView as ItemListingBinding)
//
//        holder.itemView.let {
//            it.textItem
//        }
    }
}*/
class MyAdapter
@Inject
constructor() : GenericAdapter<String>(R.layout.item_listing) {

    override fun onBindViewHolder(holder: GenericViewHolder<String>, position: Int) {
        super.onBindViewHolder(holder, position)
        holder.itemView.let {

        }
    }
}