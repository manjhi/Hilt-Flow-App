package com.app.latestdemo.services

import android.content.Context
import android.net.ConnectivityManager
import com.app.latestdemo.common.DispatcherProvider
import com.app.latestdemo.common.MyApplication
import com.app.latestdemo.domain.dto.ApiResponse
import kotlinx.coroutines.flow.*
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Response
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/**
 * Created by Manjinder Singh on 31,January,2022
 */
suspend fun <T> genericApiCall(
    dispatchers: DispatcherProvider,
    call: suspend () -> Response<ApiResponse<T>>
): Flow<ResultResource<T>> =
    flow {
        if (isConnected()) {
            call.invoke().run {
                if (this.isSuccessful) {
                    this.body()?.let {
                        if (this.body()?.success == 200)
                            emit(ResultResource.Success(it.data, it.msg, Status.SUCCESS))
                        else
                            emit(ResultResource.Error(message = it.msg.toString(), status = Status.ERROR))
                    }
                } else {
                    val error = this.errorBody()?.string()

                    val message = StringBuilder()
                    error?.let {
                        try {
                            message.append(JSONObject(it).getString("message"))
                            if (this.code() == 401)
                                emit(
                                    ResultResource.Error(
                                        message = message.toString(),
                                        status = Status.UNAUTHORIZED
                                    )
                                )
                            else
                                emit(ResultResource.Error(message = message.toString(), status = Status.ERROR))
                        } catch (e: JSONException) {
                            message.append(error)
                            if (this.code() == 401) {
                                emit(
                                    ResultResource.Error(
                                        message = message.toString(),
                                        status = Status.UNAUTHORIZED
                                    )
                                )
                            } else
                                emit(ResultResource.Error(this.message(), Status.ERROR))
                        }
                    }
                }
            }
        } else {
            emit(ResultResource.Error("Please connect to Internet", Status.ERROR))
        }
    }.onStart {
        emit(ResultResource.Loading)
    }.catch { e ->
        when (e) {
            is ConnectException, is UnknownHostException, is SocketTimeoutException -> {
                emit(ResultResource.NetworkError("Failed to connect server", Status.ERROR))
            }
            else -> {
                emit(ResultResource.NetworkError(e.message.toString(), Status.ERROR))
            }
        }

    }.flowOn(dispatchers.io)


@Suppress("DEPRECATION")
fun isConnected(): Boolean {
    val cm =
        MyApplication.application.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val activeNetwork = cm.activeNetworkInfo
    return activeNetwork != null && activeNetwork.isConnected
}