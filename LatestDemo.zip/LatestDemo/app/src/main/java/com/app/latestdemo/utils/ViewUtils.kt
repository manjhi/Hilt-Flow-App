package com.app.latestdemo.utils

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.content.ContextCompat
import com.app.latestdemo.MainActivity
import com.app.latestdemo.R
import com.google.android.material.snackbar.Snackbar

/**
 * Created by Manjinder Singh on 31,January,2022
 */

fun Any?.isNull() = this == null

fun View.showSnackBar(message: String) {
    Snackbar.make(this, message, Snackbar.LENGTH_LONG)
        .setBackgroundTint(ContextCompat.getColor(this.context, R.color.black))
        .setTextColor(ContextCompat.getColor(this.context, R.color.white))
        .show()
}

fun Activity.toStart() {
    Intent(this, MainActivity::class.java).also {
        it.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(it)
    }
}



fun Context.showDialogFix(layout: Int): Dialog {
    val dialog = Dialog(this)
    dialog.setContentView(layout)
    val lp = WindowManager.LayoutParams()
    lp.copyFrom(dialog.window!!.attributes)
    lp.width = WindowManager.LayoutParams.MATCH_PARENT
    lp.height = WindowManager.LayoutParams.WRAP_CONTENT
    lp.gravity = Gravity.CENTER
    dialog.window!!.attributes = lp
    dialog.setCancelable(false)
    dialog.setCanceledOnTouchOutside(false)
    return dialog
}