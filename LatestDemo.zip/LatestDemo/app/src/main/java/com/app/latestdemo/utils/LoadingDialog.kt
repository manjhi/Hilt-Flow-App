package com.app.latestdemo.utils

import android.app.Dialog
import android.content.Context
import android.os.Build
import android.view.View
import android.view.WindowManager
import android.widget.ProgressBar
import androidx.annotation.RequiresApi
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.view.isVisible
import com.app.latestdemo.R

class LoadingDialog(context: Context?) {

    private var dialog: Dialog
    private var progressBar: ProgressBar? = null
    private var ivlogo: AppCompatImageView? = null
    private var progressBarNormal: ProgressBar? = null

    init {
        val dialogView = View.inflate(context, R.layout.progress_dialog, null)
        dialog = Dialog(context!!, R.style.CustomDialog)
        dialog.setContentView(dialogView)
        dialog.setCancelable(false)
        progressBar = dialogView.findViewById(R.id.progressBar)
        progressBarNormal = dialogView.findViewById(R.id.progressBarNormal)
        ivlogo = dialogView.findViewById(R.id.ivLogo)
        dialog.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
    }


    private fun show() {

        if (!dialog.isShowing) {
            try {
                if (progressBar?.isVisible == false || progressBarNormal?.isVisible == true) {
                    progressBar?.isVisible = true
                    ivlogo?.isVisible = true
                    progressBarNormal?.isVisible = false
                }

                System.gc()
                dialog.show()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun showDialog() {

        if (!dialog.isShowing) {
            try {
                System.gc()
                dialog.show()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }


    fun showPercentageDialog() {
        progressBar?.isVisible = false
        ivlogo?.isVisible = false
        progressBarNormal?.isVisible = true
    }

    @RequiresApi(Build.VERSION_CODES.N)
    fun setProgress(progress: Float) {
        if (dialog.isShowing)
            progressBarNormal?.setProgress(progress.toInt(), true)
    }


    private fun dismiss() {

        System.gc()

        if (dialog.isShowing)
            dialog.dismiss()
    }

    fun setLoading(isLoading: Boolean, message: String? = null) {
        if (isLoading) {
            show()
        } else
            dismiss()
    }

}