package com.app.latestdemo.utils

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.content.ContextCompat
import androidx.databinding.BindingAdapter
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.app.latestdemo.MainActivity
import com.app.latestdemo.R
import com.app.latestdemo.common.DataBindingAdapter
import com.google.android.material.snackbar.Snackbar

/**
 * Created by Manjinder Singh on 31,January,2022
 */

fun Any?.isNull() = this == null

fun View.showSnackBar(message: String) {
    Snackbar.make(this, message, Snackbar.LENGTH_LONG)
        .setBackgroundTint(ContextCompat.getColor(this.context, R.color.black))
        .setTextColor(ContextCompat.getColor(this.context, R.color.white))
        .show()
}

fun Activity.toStart() {
    Intent(this, MainActivity::class.java).also {
        it.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(it)
    }
}


fun Context.showDialogFix(layout: Int): Dialog {
    val dialog = Dialog(this)
    dialog.setContentView(layout)
    val lp = WindowManager.LayoutParams()
    lp.copyFrom(dialog.window!!.attributes)
    lp.width = WindowManager.LayoutParams.MATCH_PARENT
    lp.height = WindowManager.LayoutParams.WRAP_CONTENT
    lp.gravity = Gravity.CENTER
    dialog.window!!.attributes = lp
    dialog.setCancelable(false)
    dialog.setCanceledOnTouchOutside(false)
    return dialog
}


fun RecyclerView.getManager(
    isItHorizontal: Boolean = false,
    isItGrid: Boolean = false,
    spanCount: Int = 2
): RecyclerView.LayoutManager {
    return if (isItGrid) {
        GridLayoutManager(this.context, spanCount)
    } else {
        if (isItHorizontal) {
            LinearLayoutManager(this.context, RecyclerView.HORIZONTAL, false)
        } else {
            LinearLayoutManager(this.context, RecyclerView.VERTICAL, false)
        }
    }
}

@BindingAdapter(value = ["setRecyclerViewAdapter", "isHorizontal", "itemList"], requireAll = false)
fun <T> setRecyclerViewAdapter(
    recyclerView: RecyclerView?,
    adapterBinding: DataBindingAdapter<T>?,
    isItHorizontal: Boolean = false,
    list: List<T>?
) {
    recyclerView?.apply {
        layoutManager = getManager(isItHorizontal)
        adapter = adapterBinding
    }
    adapterBinding?.submitList(list)
}

fun dummyList(size: Int): ArrayList<String> {
    val items: ArrayList<String> = ArrayList()
    for (i in 0 until size) {
        items.add("Item $i")
    }
    return items
}