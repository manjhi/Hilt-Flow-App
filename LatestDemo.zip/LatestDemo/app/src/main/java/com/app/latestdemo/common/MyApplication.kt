package com.app.latestdemo.common

import android.app.Application
import android.content.Context
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber

/**
 * Created by Manjinder Singh on 31,January,2022
 */
@HiltAndroidApp
class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        application = this
        initTimber()
    }


    companion object {
        lateinit var application: Context
    }

    private fun initTimber() {
        Timber.plant(Timber.DebugTree())
    }
}