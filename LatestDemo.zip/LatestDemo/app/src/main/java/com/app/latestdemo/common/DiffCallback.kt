package com.app.latestdemo.common

import androidx.recyclerview.widget.DiffUtil

/**
 * Created by Manjinder Singh on 11,June,2021
 */
class DiffCallback : DiffUtil.ItemCallback<String>() {
    override fun areItemsTheSame(
        oldItem: String,
        newItem: String
    ): Boolean {
        return oldItem.toString() == newItem.toString()
    }

    override fun areContentsTheSame(
        oldItem: String,
        newItem: String
    ): Boolean {
        return oldItem == newItem
    }
}

class DiffCallbackClass<T> : DiffUtil.ItemCallback<T>() {
    override fun areItemsTheSame(
        oldItem: T,
        newItem: T
    ): Boolean {
        return oldItem.toString() == newItem.toString()
    }

    override fun areContentsTheSame(
        oldItem: T,
        newItem: T
    ): Boolean {
        return oldItem.toString() == newItem.toString()
    }
}