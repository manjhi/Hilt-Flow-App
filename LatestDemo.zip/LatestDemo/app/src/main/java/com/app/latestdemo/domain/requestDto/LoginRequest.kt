package com.app.latestdemo.domain.requestDto

/**
 * Created by Manjinder Singh on 31,January,2022
 */
data class LoginRequest(
    val AppType: Int = 2,
    val DeviceToken: String,
    val Email: String,
    val Password: String
)