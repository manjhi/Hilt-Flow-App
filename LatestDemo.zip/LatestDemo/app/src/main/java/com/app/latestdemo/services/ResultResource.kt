package com.app.latestdemo.services

/**
 * Created by Manjinder Singh on 31,January,2022
 */

sealed class ResultResource<out T>(
    val data: T? = null,
    val msg: String? = null,
    val status: Status? = null
) {

    object Loading : ResultResource<Nothing>()

    class Success<out T>(data: T?, msg: String?, status: Status?) :
        ResultResource<T>(data = data, msg = msg, status = status)

    class Error(message: String, status: Status) : ResultResource<Nothing>(
        msg = message,
        status = status
    )
    class NetworkError(message: String, status: Status) : ResultResource<Nothing>(
        msg = message,
        status = status
    )
}

enum class Status {
    SUCCESS,
    ERROR,
    LOADING,
    UNAUTHORIZED,
    NETWORK_ISSUE
}