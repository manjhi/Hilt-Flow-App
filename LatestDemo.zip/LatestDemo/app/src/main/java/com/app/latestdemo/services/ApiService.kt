package com.app.latestdemo.services

import com.app.latestdemo.domain.dto.ApiResponse
import com.app.latestdemo.domain.requestDto.LoginRequest
import com.app.latestdemo.services.NetworkParams.LOGIN
import com.google.gson.JsonObject
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

/**
 * Created by Manjinder Singh on 31,January,2022
 */
interface ApiService {

    @POST(LOGIN)
    suspend fun login(@Body jsonObject: LoginRequest): Response<ApiResponse<Any>>
}