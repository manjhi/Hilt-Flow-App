package com.app.latestdemo.di

import android.content.Context
import com.app.latestdemo.BuildConfig
import com.app.latestdemo.common.DispatcherProvider
import com.app.latestdemo.manager.appManager.AppDataManager
import com.app.latestdemo.manager.appManager.DataManager
import com.app.latestdemo.manager.dataStore.DataStoreHelper
import com.app.latestdemo.services.ApiService
import com.app.latestdemo.services.AuthenticationInterceptor
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.DelicateCoroutinesApi
import okhttp3.Cache
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import timber.log.Timber
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

/**
 * Created by Manjinder Singh on 31,January,2022
 */

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Singleton
    @Provides
    fun provideGsonBuilder(): Gson {
        return GsonBuilder()
            .setLenient()
            .create()
    }

    @Provides
    @Singleton
    fun providesOkhttpCache(@ApplicationContext appContext: Context,): Cache {
        return Cache(appContext.cacheDir, 1024)
    }

    @Singleton
    @Provides
    fun providersLoggingInterceptor(): HttpLoggingInterceptor {
        val interceptor = HttpLoggingInterceptor { message ->
            Timber.e(
                "Log: $message"
            )
        }
        interceptor.level = HttpLoggingInterceptor.Level.BODY
        return interceptor
    }

    @DelicateCoroutinesApi
    @Singleton
    @Provides
    fun providedAuthenticationInterceptor(dataStoreHelper: DataStoreHelper): AuthenticationInterceptor {
        return AuthenticationInterceptor(
            dataStoreHelper
        )
    }


    @DelicateCoroutinesApi
    @Singleton
    @Provides
    fun providesOkHttpClient(
        cache: Cache,
        loggingInterceptor: HttpLoggingInterceptor,
        authenticationInterceptor: AuthenticationInterceptor
    ): OkHttpClient {
        return OkHttpClient.Builder()
            .cache(cache)
            .addInterceptor(authenticationInterceptor)
            .addInterceptor(loggingInterceptor)
            .connectTimeout(6, TimeUnit.SECONDS)
            .writeTimeout(6, TimeUnit.SECONDS)
            .readTimeout(6, TimeUnit.SECONDS)
            .build()
    }

    @Singleton
    @Provides
    fun provideRetrofit(gson: Gson, okHttpClient: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BuildConfig.SERVER_URL)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .client(okHttpClient)
            .build()

    }

    @Singleton
    @Provides
    fun provideApiService(retrofit: Retrofit): ApiService {
        return retrofit
            .create(ApiService::class.java)
    }

    @Singleton
    @Provides
    fun provideAppManager(
        mPreferencesHelper: DataStoreHelper,
        mApiHelper: ApiService,
        dispatcherProvider: DispatcherProvider
    ): DataManager {
        return AppDataManager(mPreferencesHelper, mApiHelper,dispatcherProvider)
    }
}