package com.app.latestdemo.di

import android.content.Context
import com.app.latestdemo.manager.dataStore.AppDataStoreImpl
import com.app.latestdemo.manager.dataStore.DataStoreHelper
import com.google.gson.Gson
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.ExperimentalCoroutinesApi
import javax.inject.Singleton

/**
 * Created by Manjinder Singh on 31,January,2022
 */

@Module
@InstallIn(SingletonComponent::class)
object DataStoreModule {

    @ExperimentalCoroutinesApi
    @Singleton
    @Provides
    fun providedDataStore(
        someString: String,
        @ApplicationContext appContext: Context,
        gson: Gson
    ): DataStoreHelper {
        return AppDataStoreImpl(appContext,someString,gson)
    }


}