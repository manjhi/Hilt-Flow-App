package com.app.latestdemo.domain.dto

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

/**
 * Created by Manjinder Singh on 31,January,2022
 */
data class ApiResponse<T>(
    @SerializedName("status")
    @Expose
    val success: Int,

    @SerializedName("message")
    @Expose
    val msg: String,


    @SerializedName("totalCount")
    @Expose
    val totalCount: Int,

    @SerializedName("result")
    @Expose
    val data: T
)