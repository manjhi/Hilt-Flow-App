package com.app.latestdemo.common

import kotlinx.coroutines.CoroutineDispatcher

/**
 * Created by Manjinder Singh on 31,January,2022
 */
interface DispatcherProvider {
    val main: CoroutineDispatcher
    val io: CoroutineDispatcher
    val default: CoroutineDispatcher
    val unconfined: CoroutineDispatcher
}