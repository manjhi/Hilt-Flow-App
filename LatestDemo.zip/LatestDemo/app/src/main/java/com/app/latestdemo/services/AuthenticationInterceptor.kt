package com.app.latestdemo.services

import com.app.latestdemo.manager.dataStore.DataStoreConstants
import com.app.latestdemo.manager.dataStore.DataStoreHelper
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import okhttp3.Interceptor
import okhttp3.Response
import javax.inject.Inject

/**
 * Created by Manjinder Singh on 31,January,2022
 */
@DelicateCoroutinesApi
class AuthenticationInterceptor
@Inject
constructor(
    private val mDataStoreHelper: DataStoreHelper,
): Interceptor {



    private var userLoggedIn = false
    private var accessToken: String? = null

    init {

        GlobalScope.launch {
            mDataStoreHelper.getCurrentUserLoggedIn().collectLatest {
                userLoggedIn = it
            }
        }


        GlobalScope.launch {
            mDataStoreHelper.getKeyValue(DataStoreConstants.ACCESS_TOKEN).collectLatest {
                accessToken = "Bearer ${it?.toString()}"
            }
        }

    }


    override fun intercept(chain: Interceptor.Chain): Response = chain.request().let {

        val requestBuilder = chain.request().newBuilder()

        requestBuilder.addHeader(NetworkParams.ACCEPT, NetworkParams.APPLICATION_JSON)

        if (userLoggedIn && !accessToken.isNullOrEmpty()) {
            requestBuilder.addHeader(NetworkParams.AUTHORIZATION, accessToken!!)
        }

        return chain.proceed(requestBuilder.build())
    }
}