package com.hiltflowdemoapp.business.data.util

/**
 * Created by Manjinder Singh on 05,January,2021
 */


object GenericErrors {

    const val ERROR_UNKNOWN = "Unknown error"
    const val INVALID_STATE_EVENT = "Invalid state event"

}