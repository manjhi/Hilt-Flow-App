package com.app.latestdemo.modules.authModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import com.app.latestdemo.common.BaseViewModel
import com.app.latestdemo.domain.requestDto.LoginRequest
import com.app.latestdemo.manager.appManager.AppDataManager
import com.app.latestdemo.services.ResultResource
import com.app.latestdemo.utils.SingleEvent
import com.google.gson.JsonObject
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.collect
import javax.inject.Inject

/**
 * Created by Manjinder Singh on 31,January,2022
 */

@HiltViewModel
@ExperimentalCoroutinesApi
class LoginViewModel
@Inject
constructor(
    private val savedStateHandle: SavedStateHandle,
    private val appDataManager: AppDataManager
) : BaseViewModel() {

    private val _loginResult = MutableLiveData<SingleEvent<ResultResource<Any>>>()
    val loginResult: LiveData<SingleEvent<ResultResource<Any>>> get() = _loginResult

    fun loginUser(jsonObject: LoginRequest) {
        launchOnUI {
            appDataManager.login(jsonObject).collect {
                _loginResult.value = SingleEvent(it)
            }
        }
    }
}