package com.app.latestdemo.di

import android.content.Context
import com.app.latestdemo.utils.LoadingDialog
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ActivityComponent
import dagger.hilt.android.qualifiers.ActivityContext
import dagger.hilt.android.scopes.ActivityScoped

/**
 * Created by Manjinder Singh on 31,January,2022
 */

@Module
@InstallIn(ActivityComponent::class)
object ActivityScopeModule {
    @ActivityScoped
    @Provides
    fun providesLoadingDialog(
        @ActivityContext context: Context
    ): LoadingDialog {
        return LoadingDialog(context)
    }

}