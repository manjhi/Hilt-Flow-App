package com.hiltflowdemoapp.base.presentation.viewmodel

/**
 * Created by Manjinder Singh on 05,January,2021
 */
interface BaseViewState