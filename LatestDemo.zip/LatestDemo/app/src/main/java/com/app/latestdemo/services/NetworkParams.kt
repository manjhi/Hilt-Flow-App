package com.app.latestdemo.services

/**
 * Created by Manjinder Singh on 31,January,2022
 */
object NetworkParams {

    const val LOGIN = "api/Account/LoginPractitioner"

    const val AUTHORIZATION = "Authorization"
    const val ACCEPT = "Accept"
    const val APPLICATION_JSON = "application/json"
}