package com.app.latestdemo.common

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import timber.log.Timber
import kotlin.coroutines.cancellation.CancellationException

/**
 * Created by Manjinder Singh on 27,January,2022
 */
abstract class BaseViewModel : ViewModel() {

    private var job: Job? = null

    fun launchOnUI(block: suspend CoroutineScope.() -> Unit) {
        job?.cancel()
        job = viewModelScope.launch(Dispatchers.IO) {
            delay(300)
            block()
        }
    }

    override fun onCleared() {
        super.onCleared()
        job?.cancel()
    }
}