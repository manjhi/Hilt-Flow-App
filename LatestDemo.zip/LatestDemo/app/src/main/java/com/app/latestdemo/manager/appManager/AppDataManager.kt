package com.app.latestdemo.manager.appManager

import androidx.datastore.preferences.core.Preferences
import com.app.latestdemo.common.DispatcherProvider
import com.app.latestdemo.domain.requestDto.LoginRequest
import com.app.latestdemo.manager.dataStore.DataStoreHelper
import com.app.latestdemo.services.ApiService
import com.app.latestdemo.services.ResultResource
import com.app.latestdemo.services.genericApiCall
import com.google.gson.JsonObject
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

/**
 * Created by Manjinder Singh on 31,January,2022
 */
class AppDataManager
@Inject
constructor(
    private val mDataStoreHelper: DataStoreHelper,
    private val mApiHelper: ApiService,
    private val dispatchers: DispatcherProvider
):DataManager{

    override suspend fun <T> setKeyValue(key: Preferences.Key<T>, value: T) {
        mDataStoreHelper.setKeyValue(key, value)
    }


    override fun <T> getKeyValue(key: Preferences.Key<T>): Flow<Any?> {
        return mDataStoreHelper.getKeyValue(key)
    }


    override suspend fun <T> getGsonValue(key: Preferences.Key<String>, type: Class<T>): Flow<T?> {
        return mDataStoreHelper.getGsonValue(key, type)
    }

    override suspend fun addGsonValue(key: Preferences.Key<String>, value: String) {
        return mDataStoreHelper.addGsonValue(key, value)
    }

    override suspend fun logOut() {
        mDataStoreHelper.logOut()
    }

    override suspend fun clear() {
        mDataStoreHelper.clear()
    }

    override suspend fun getCurrentUserLoggedIn(): Flow<Boolean> {
        return mDataStoreHelper.getCurrentUserLoggedIn()
    }

    override suspend fun login(jsonObject: LoginRequest): Flow<ResultResource<Any>> {
        return genericApiCall(dispatchers){
            mApiHelper.login(jsonObject)
        }
    }
}