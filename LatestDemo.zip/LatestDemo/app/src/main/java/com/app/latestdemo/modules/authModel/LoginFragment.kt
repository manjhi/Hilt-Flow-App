package com.app.latestdemo.modules.authModel

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.app.latestdemo.R
import com.app.latestdemo.common.BaseFragment
import com.app.latestdemo.databinding.FragmentLoginBinding
import com.app.latestdemo.domain.requestDto.LoginRequest
import com.app.latestdemo.utils.SessionScrollListener
import com.app.latestdemo.utils.dummyList
import com.app.latestdemo.utils.showSnackBar
import com.google.gson.Gson
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import timber.log.Timber
import javax.inject.Inject

@ExperimentalCoroutinesApi
@AndroidEntryPoint
class LoginFragment : BaseFragment<FragmentLoginBinding>() {

    private lateinit var binding: FragmentLoginBinding

    private val viewModel: LoginViewModel by viewModels()

    override val layoutResourceId: Int
        get() = R.layout.fragment_login


    @Inject
    lateinit var myAdapter: MyAdapter

    var listing = dummyList(15)

    override fun showError(message: String) {
        Timber.e(message)
        binding.clickButton.showSnackBar(message)
    }

    override fun showNetworkError() {

    }


    override fun initView() {
        binding = getViewDataBinding()


        binding.clickButton.setOnClickListener {
            var request = LoginRequest(
                Email = "danish@mailinator.com",
                Password = "12345678",
                DeviceToken = "FCM@SampleToken"
            )
            viewModel.loginUser(request)
        }
        observeLoginRequest()


        assignManagerSession(binding.recyclerView, LinearLayoutManager(requireActivity()))


    }

    private fun assignManagerSession(recyclerView: RecyclerView, layoutManager: LinearLayoutManager) {
        val scrollListener = SessionScrollListener(layoutManager) {
            binding.recyclerView.post {
                val itemSize = listing.size
                listing.addAll(dummyList(15))
                myAdapter.addItems(listing)
            }
        }
        recyclerView.addOnScrollListener(scrollListener)
        layoutManager.orientation=LinearLayoutManager.VERTICAL
        recyclerView.layoutManager = layoutManager
        myAdapter.addItems(listing)
        binding.recyclerView.adapter = myAdapter
    }

    private fun observeLoginRequest() {
        viewModel.loginResult.observe(viewLifecycleOwner) { result ->
            result.getContentIfNotHandled()?.let { response ->
                if (checkStatus(false, result.peekContent(), result.peekContent().msg)) {
                    runBlocking {
//                        Timber.e(Gson().toJson(response.data))
//                        binding.clickButton.performClick()
                    }
                }
            }
        }

    }

    override fun initData() {

    }
}